from .nnEngine import NN
from .nnEngine import tanh, dtanh
from .nnEngine import sigm, dsigm
from .nnEngine import relu, drelu
__all__ = ["NN", "tahn", "dtahn", "sigm", "dsigm", "relu", "drelu"]
