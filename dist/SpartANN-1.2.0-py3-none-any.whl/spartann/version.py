"""
SpartANN - Spectral Pattern Analysis and Remote-sensing Tool with Artificial Neural Networks
Copyright (C) 2025 Pedro Tarroso

"""
__all__ = ["__version__"]
__version__ = "1.2.0"
